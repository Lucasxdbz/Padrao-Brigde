public class ControleBasico extends ControleRemoto{
    public ControleBasico(Aparelho aparelho) {
        super(aparelho);
    }

    public void usar() {
        System.out.println("-- Controle Básico --");
        ligar();
        trocarCanal(5);
        desligar();
    }
}
