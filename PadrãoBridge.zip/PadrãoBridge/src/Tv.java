public class Tv implements Aparelho {
    @Override
    public void ligar() {
        System.out.println("Tv Ligada");
    }

    @Override
    public void desligar() {
        System.out.println("Tv Desligada");
    }

    @Override
    public void trocarcanal(int canal) {
        System.out.println("Tv: trocando para o canal " + canal);
    }
}
