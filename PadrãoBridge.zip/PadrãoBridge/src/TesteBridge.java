public class TesteBridge {
    public static void main(String[] args) {
        System.out.println("=== Controle basico + TV ====");
        ControleBasico controle1 = new ControleBasico(new Tv());
        controle1.usar();
    }
}
