public interface Aparelho {
            void ligar();
            void desligar();
            void trocarcanal(int canal);
}

