public class DVD implements Aparelho {
    public void ligar() {
        System.out.println("DVD ligado.");
    }
    public void desligar() {
        System.out.println("DVD desligado.");
    }
    public void trocarcanal(int canal) {
        System.out.println("DVD: trocando para a faixa " + canal + ".");
    }
}
