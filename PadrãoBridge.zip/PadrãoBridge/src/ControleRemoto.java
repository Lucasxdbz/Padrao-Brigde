abstract class ControleRemoto {
    // A "ponte"
    protected Aparelho aparelho;

    public ControleRemoto(Aparelho aparelho) {
        this.aparelho = aparelho;
    }

    // Delega as ações para o aparelho
    public void ligar()            { aparelho.ligar(); }
    public void desligar()         { aparelho.desligar(); }
    public void trocarCanal(int c) { aparelho.trocarcanal(c); }

}

